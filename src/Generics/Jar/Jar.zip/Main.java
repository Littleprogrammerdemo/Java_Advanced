package Generics.Jar;

public class Main {
    public static void main(String[] args) {
        Jar<String> myJar = new Jar<String>();

    }
}
